<template>
	<div class="intro">
		<h3>评审小组须知</h3>
		<p>助学金评审本着公开公平公正透明的原则，您的身份是<span class="bold">评审小组负责人</span>，在本次评审中您负责<span class="bold">提出评审意见</span>和<span class="bold">审核打分情况</span>，在操作完成后，点击对应<span class="bold">保存按钮</span>，方可生效！</p>
	</div>
</template>
<script>
	export default{
		
	}
</script>
<style scoped lang="less">
	.intro{
		width:100%;
		height: 100%;
		padding:10px;
		p{
			text-indent: 2em;
			margin-top:10px;
		}
		.bold{
			font-size:18px;
			font-weight: bold;
		}
	}
</style>