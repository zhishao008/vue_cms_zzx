let state = {
	// 基本信息
	basedDetail:false,//学生基本信息
	studentdata:{},//获取到当前页的学生信息数据
	detailindex:1, // 查看学生信息详情的索引
	userdata:{},//获取当前页的账号信息数据
	scoredata:{},//获取当前页的得分数据
	atclss:0
}
export default state;